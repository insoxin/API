##tinyurl 短网址生成还原工具
**利用短网址服务商提供的API实现.**  
演示:http://app.baidu.com/app/enter?appid=408152
