<?php
readfile("images/".$_GET['name']);
?>